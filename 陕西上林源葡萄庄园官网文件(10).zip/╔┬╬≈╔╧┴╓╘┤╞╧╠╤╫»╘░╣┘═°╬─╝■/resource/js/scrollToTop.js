function scrollToTop () {
    window.scrollTo({
        left: 0,
        top: 0,
        behavior: 'smooth'
    })
}

// const firstElement = document.getElementsByClassName("nylm_1")[0];
// if (firstElement.clientLeft < document.documentElement.offsetWidth - 4){
//     console.log(123);
// }